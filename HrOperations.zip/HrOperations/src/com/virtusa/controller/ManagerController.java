package com.virtusa.controller;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.factory.FactoryManagerService;
import com.virtusa.model.ManagerModel;
import com.virtusa.service.ManagerService;
import com.virtusa.view.ManagerView;

public class ManagerController {

	
	private ManagerService managerService;
	public ManagerController(){
		this.managerService=FactoryManagerService.createManagerService();
		
	}
	
      public void viewApplication(){
		
		List<ManagerModel> managerModelList=managerService.retrieveApplicationService();
		ManagerView managerView=new ManagerView();
		managerView.displayApplicationDetails(managerModelList);
	}
	public void scheduleInterview(ManagerModel managerModel){
		
		boolean result=managerService.scheduleInterviewService(managerModel);
		ManagerView managerView=new ManagerView();
		if(result){
			managerView.storeSuccessful();
		}else{
			
			managerView.storeUnSuccessful();
		}

	}
		public void retrieveInterviewer(String interviewerId) {
			// TODO Auto-generated method stub
			ManagerView managerView=new ManagerView();
			ManagerModel manager=managerService.retrieveInterviewer(interviewerId);
			
			managerView.showInterviewer(manager);
		}

		public void resultUpdate() throws ClassNotFoundException,SQLException
		{
			ManagerView managerView=new ManagerView();
			List<ManagerModel> managerModelList=managerService.retrieveResultUpdate();
			managerView.displayResultUpdate(managerModelList);
		}
	}
	