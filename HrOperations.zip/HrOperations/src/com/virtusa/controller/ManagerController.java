package com.virtusa.controller;

import java.util.List;

import com.virtusa.factory.FactoryManagerService;
import com.virtusa.model.ManagerModel;
import com.virtusa.service.ManagerService;
import com.virtusa.view.ManagerView;

public class ManagerController {

	
	private ManagerService managerService;
	public ManagerController(){
		this.managerService=FactoryManagerService.createManagerService();
		
	}
	
	public void storeApplication(ManagerModel managerModel){
		
		boolean result=managerService.storeApplicationService(managerModel);
		ManagerView managerView=new ManagerView();
		if(result){
			managerView.storeSuccessful();
		}else{
			
			managerView.storeUnSuccessful();
		}
		public void retrieveInterviewer(int deptId)
		{
			ManagerModel manager=managerService.retrieveInterviewer(deptId);
		
			managerView.showInterviewer(manager);
			
		}
		
	}
	

	public void viewApplication(){
		
		List<ManagerModel> managerModelList=managerService.retrieveApplicationService();
		ManagerView managerView=new ManagerView();
		managerView.displayApplicationDetails(managerModelList);
	}

	public void retrieveInterviewer(int deptId) {
		// TODO Auto-generated method stub
		
	}

}