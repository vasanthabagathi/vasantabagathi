package com.virtusa.model;

public class ManagerModel {
private String interviewerId;
	public String getInterviewerId() {
	return interviewerId;
}
public void setInterviewerId(String interviewerId) {
	this.interviewerId = interviewerId;
}
	private String date;
	private String venue;
	private String resultUpdate;
	public String getResultUpdate() {
		return resultUpdate;
	}
	public void setResultUpdate(String resultUpdate) {
		this.resultUpdate = resultUpdate;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String interviewDate) {
		this.date = date;
	}
	public String getVenue() {
		return venue;
	}
	public void setVenue(String interviewVenue) {
		this.venue = venue;
	}
	@Override
	public String toString() {
		return "ManagerModel [interviewerId=" + interviewerId + ", date=" + date + ", venue=" + venue
				+ ", resultUpdate=" + resultUpdate + "]";
	}
	
	}
