package com.virtusa.model;

public class ManagerModel {

	private String interviewDate;
	private String interviewVenue;
	private String resultUpdate;
	public String getResultUpdate() {
		return resultUpdate;
	}
	public void setResultUpdate(String resultUpdate) {
		this.resultUpdate = resultUpdate;
	}
	public String getInterviewDate() {
		return interviewDate;
	}
	public void setInterviewDate(String interviewDate) {
		this.interviewDate = interviewDate;
	}
	public String getInterviewVenue() {
		return interviewVenue;
	}
	public void setInterviewVenue(String interviewVenue) {
		this.interviewVenue = interviewVenue;
	}
	@Override
	public String toString() {
		return "ManagerModel [interviewDate=" + interviewDate + ", interviewVenue=" + interviewVenue + ", resultUpdate="
				+ resultUpdate + "]";
	}
	
}
