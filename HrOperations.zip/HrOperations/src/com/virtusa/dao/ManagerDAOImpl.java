package com.virtusa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.entities.Admin;
import com.virtusa.entities.Interview;
import com.virtusa.entities.Manager;
import com.virtusa.entities.User;
import com.virtusa.integrate.ConnectionManager;
import com.virtusa.repository.ManagerRepository;

public class ManagerDAOImpl implements ManagerDAO {

	private String interviewerId;
	User user=new User();
	public List<User> assignInterviewer() throws ClassNotFoundException, SQLException {
			// TODO Auto-generated method stub
			Connection connection=ConnectionManager.openConnection();
			PreparedStatement statement=connection.prepareStatement("select u.userName from users u join employee e on u.userId=e.userId and  designation='�nterviewer'");
			ResultSet resultSet=statement.executeQuery();
			List<User> userList=new ArrayList<>();
			while(resultSet.next()) { 
				
				user.setUserName(resultSet.getString("userName"));
				userList.add(user);
			}	
  				ConnectionManager.closeConnection();
  				
				return userList;
	}
			/*	@Override
				public  boolean  (Admin admin)throws ClassNotFoundException, SQLException {
					// TODO Auto-generated method stub
					Connection connection=ConnectionManager.openConnection();
					Statement statement=connection.createStatement();
					ResultSet resultSet=
							statement.executeQuery("select date,venue from interview");
					
					List<Interview> intereviewerList=new ArrayList<Interview>();
					while(resultSet.next()) {
						Interview interview=new Interview();
						interview.setVenue(resultSet.getString("venue"));
						java.sql.Date 
						interview_date=resultSet.getDate("date");
						
						interview.setDate(interview_date.toLocalDate());
						intereviewerList.add(interview);
					}
					ConnectionManager.closeConnection();
					return false;
				}
				
				 
				@Override
				public List<Manager> viewApplications() {
					// TODO Auto-generated method stub
					return null;
				}
				
					@Override
					public List<Manager> viewResultUpdate() throws ClassNotFoundException,SQLException
					{
						Connection connection=null;
						connection=ConnectionManager.openConnection();
						PreparedStatement statement=connection.prepareStatement("select resultUpdate from applicant");
						ResultSet resultSet=statement.executeQuery();
						List<Manager> resultUpdateList=new ArrayList<Manager>();
						while(resultSet.next()) 
						{
							Manager manager=new Manager();
							manager.setResultUpdate(resultSet.getString(1));
							resultUpdateList.add(manager);
						}
						return resultUpdateList;
					}*/

}
