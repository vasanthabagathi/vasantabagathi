package com.virtusa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.entities.Admin;
import com.virtusa.entities.Interview;
import com.virtusa.entities.Manager;
import com.virtusa.integrate.ConnectionManager;
import com.virtusa.repository.ManagerRepository;

public class ManagerDAOImpl implements ManagerDAO {

	private String interviewerId;
	public Interview assignInterviewer(Manager manager) throws ClassNotFoundException, SQLException {
			// TODO Auto-generated method stub
			Connection connection=ConnectionManager.openConnection();
			PreparedStatement statement=connection.prepareStatement("select interviewerid,designation\r\n"+
					"from employee\r\n"+
					"where interviewerid=?;"
					);
			statement.setString(1, interviewerId);
			ResultSet resultSet=statement.executeQuery();
			Interview interview=new Interview();
			while(resultSet.next()) { 
				
				interview.setInterviewerId(resultSet.getString("interviewerId"));
			}	
  				ConnectionManager.closeConnection();
				return interview;
	}
				@Override
				public List<Interview> getInterviewerId() throws ClassNotFoundException, SQLException {
					// TODO Auto-generated method stub
					Connection connection=ConnectionManager.openConnection();
					Statement statement=connection.createStatement();
					ResultSet resultSet=
							statement.executeQuery("select * from interview");
					
					List<Interview> intereviewerList=new ArrayList<Interview>();
					while(resultSet.next()) {
						Interview interview=new Interview();
						interview.setInterviewerId(resultSet.getString("interviewer_id"));
						interview.setInterviewVenue(resultSet.getString("intrview_venue"));
						java.sql.Date 
						interview_date=resultSet.getDate("interview_date");
						
						interview.setInterviewDate(interview_date.toLocalDate());
						intereviewerList.add(interview);
					}
					ConnectionManager.closeConnection();
					return intereviewerList;
				}
				
				 
				@Override
				public List<Manager> viewApplications() {
					// TODO Auto-generated method stub
					return null;
				}
				
					

}
