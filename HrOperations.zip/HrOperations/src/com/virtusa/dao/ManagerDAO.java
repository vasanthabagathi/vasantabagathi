package com.virtusa.dao;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.entities.Applicant;
import com.virtusa.entities.Interview;
import com.virtusa.entities.Manager;

public interface ManagerDAO {

	public List<Manager> viewApplications();

	List<Interview> getInterviewerId() throws ClassNotFoundException, SQLException;

	List<Manager> viewResultUpdate() throws ClassNotFoundException, SQLException;
}
