package com.virtusa.view;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

import com.virtusa.controller.ManagerController;
import com.virtusa.model.ApplicantModel;
import com.virtusa.model.ManagerModel;
import com.virtusa.model.UserModel;
import com.virtusa.userinteface.UserInterface;

public class ManagerView {
	public void managerView() throws ClassNotFoundException, SQLException {
		System.out.println("=======Manager View======");
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("1. View application:");
		System.out.println("2. Schedule interview:");
		System.out.println("3. Assign interviewer:");
		System.out.println("4. Result update:");
		System.out.println("Enter option");
		int option=scanner.nextInt();
		ManagerView managerView=new ManagerView();
		
		if(option==1){
			ManagerController managerController=new ManagerController();
	           managerController.viewApplication();
			}
		if(option==2){
			
			managerView.scheduleInterview();
			}
		if(option==3)
			try {
				{
					ManagerController managerController=new ManagerController();
					managerController.retrieveInterviewer();
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	     if(option==4)
	     {
	    	 
	     }
		}

	private void scheduleInterview() throws ClassNotFoundException, SQLException {
		Scanner scanner=new Scanner(System.in);
		System.out.print("Date(DD/MM/YYYY):");
		String dateString=scanner.next();
		
		StringTokenizer tokens=new StringTokenizer(toString(),"/");
		
		List<String> tokensList=new ArrayList<>();
		while(tokens.hasMoreTokens()) {
			tokensList.add(tokens.nextToken());
		}
		
		int dayOfMonth=Integer.parseInt(tokensList.get(0));
		int month=Integer.parseInt(tokensList.get(1));
		int year=Integer.parseInt(tokensList.get(2));
		
		LocalDate date=LocalDate.of(year, month-1, dayOfMonth);
		
		System.out.print("Enter interview venue");
		String interviewVenue=scanner.next();
		
		System.out.println("\n");
		
		ManagerModel managerModel =new ManagerModel();
		managerModel.setDate(dateString);
		managerModel.setVenue(interviewVenue);
		managerView();
	
	}
	

	public void showInterviewer(List<ManagerModel> manager)
	{
		for(ManagerModel managerModel :manager){
			
    		System.out.print("\n Interviewer List:"+managerModel.getUsername());
    		
    	
    	}
		
    }
	public void storeSuccessful(){
		
		System.out.println("Interview scheduled successful");
	}
	
    public void storeUnSuccessful(){
		
		System.out.println("Unable to schedule");
	}
    
    private void assignInterviewer() {
		ManagerController managerController=new ManagerController();
		  
		  try(Scanner scanner=new Scanner(System.in);){
			  System.out.print("Please Enter Interviewers:");
			  //String interviewerId=scanner.next();
		      managerController.retrieveInterviewer();
			  
		  }catch(Exception e) {
			  e.printStackTrace();
		  }
		
	}

	public void displayApplicationDetails(List<ManagerModel> managerModelList) {
		// TODO Auto-generated method stub
		
	}
public void displayResultUpdate(List<ManagerModel>managerModelList) {
	for(ManagerModel managerModel:managerModelList)
	{
		System.out.println("\n Result Status:"+managerModel.getResultUpdate());
	}
}


}

        
