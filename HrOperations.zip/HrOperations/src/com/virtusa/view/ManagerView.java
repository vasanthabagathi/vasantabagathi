package com.virtusa.view;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

import com.virtusa.controller.ManagerController;
import com.virtusa.model.ApplicantModel;
import com.virtusa.model.ManagerModel;
import com.virtusa.userinteface.UserInterface;

public class ManagerView {
	public void managerView() {
		System.out.println("=======Manager View======");
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("1. View application:");
		System.out.println("2. Schedule interview:");
		System.out.println("3. Assign interviewer:");
		System.out.println("4. Result update:");
		System.out.println("Enter option");
		int option=scanner.nextInt();
		ManagerView managerView=new ManagerView();
		
		if(option==1){
			ManagerController managerController=new ManagerController();
	           managerController.viewApplication();
			}
		if(option==2){
			
			managerView.scheduleInterview();
			}
		if(option==3)
		{
		
		}
	     if(option==4)
	     {
	    	 
	     }
		}

	private void scheduleInterview() {
		Scanner scanner=new Scanner(System.in);
		System.out.print("Date(DD/MM/YYYY):");
		String interviewDateString=scanner.next();
		
		StringTokenizer tokens=new StringTokenizer(interviewDateString(),"/");
		
		List<String> tokensList=new ArrayList<>();
		while(tokens.hasMoreTokens()) {
			tokensList.add(tokens.nextToken());
		}
		
		int dayOfMonth=Integer.parseInt(tokensList.get(0));
		int month=Integer.parseInt(tokensList.get(1));
		int year=Integer.parseInt(tokensList.get(2));
		
		LocalDate date=date.of(year, month-1, dayOfMonth);
		
		System.out.print("Enter interview venue");
		String interviewVenue=scanner.next();
		
		System.out.println("\n");
		
		ManagerModel managerModel =new ManagerModel();
		managerModel.setInterviewDate(interviewDate);
		managerModel.setInterviewVenue(interviewVenue);
		ManagerController managerController=new ManagerController();
		managerController.storeApplication(managerModel);
		managerView();
	
	}
	

	public void displayApplicationDetails(List<ManagerModel> managerModel)
	{
    	managerModel.forEach(System.out::println);
    }
	public void storeSuccessful(){
		
		System.out.println("Interview scheduled successful");
	}
	
    public void storeUnSuccessful(){
		
		System.out.println("Unable to schedule");
	}
    
    private void assignManager() {
		ManagerController managerController=new ManagerController();
		  
		  try(Scanner scanner=new Scanner(System.in);){
			  System.out.print("Please Enter Department Id:");
			  int deptId=scanner.nextInt();
		      managerController.retrieveInterviewer(deptId);
			  
			  
		  }catch(Exception e) {
			  e.printStackTrace();
		  }
	       
		
	}

	public void showInterviewer(ManagerModel manager) {
		// TODO Auto-generated method stub
		
	}
}

        
