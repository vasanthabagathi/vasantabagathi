package com.virtusa.entities;

public class Applicant extends User {
  
public Applicant() {
		
	}
	private Job job;
	public Job getJob() {
		return job;
	}
	public void setJob(Job job) {
		this.job = job;
	}
	private String applicantId;
	public String getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}
	private Resume resume;
	public Resume getResume() {
		return resume;
	}
	public void setResume(Resume resume) {
		this.resume = resume;
	}
	@Override
	public String toString() {
		return "Applicant [job=" + job + ", applicantId=" + applicantId + ", resume=" + resume + "]";
	}
	
}
