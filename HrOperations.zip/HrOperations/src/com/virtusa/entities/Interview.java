package com.virtusa.entities;

import java.time.LocalDate;

public class Interview {

	private String interviewerId;
	private LocalDate interviewDate;
	private String interviewVenue;
	@Override
	public String toString() {
		return "Interview [interviewerId=" + interviewerId + ", interviewDate=" + interviewDate + ", interviewVenue="
				+ interviewVenue + ", resultUpdate=" + resultUpdate + "]";
	}
	public String getInterviewerId() {
		return interviewerId;
	}
	public void setInterviewerId(String interviewerId) {
		this.interviewerId = interviewerId;
	}
	public LocalDate getInterviewDate() {
		return interviewDate;
	}
	public void setInterviewDate(LocalDate localDate) {
		this.interviewDate = localDate;
	}
	public String getInterviewVenue() {
		return interviewVenue;
	}
	public void setInterviewVenue(String interviewVenue) {
		this.interviewVenue = interviewVenue;
	}
	public String getResultUpdate() {
		return resultUpdate;
	}
	public void setResultUpdate(String resultUpdate) {
		this.resultUpdate = resultUpdate;
	}
	private String resultUpdate;
}
