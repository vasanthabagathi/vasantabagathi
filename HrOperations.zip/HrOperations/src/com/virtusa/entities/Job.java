package com.virtusa.entities;

public class Job {
	private int JobId;
	private String jobTitle;
	private String eligibilityCriteria;
	private int opportunityId;
	private String interviewId;
	private String interviewDate;
	private String interviewVenue;
	public String getInterviewerId() {
		return interviewId;
	}
	public void setInterviewerId(String interviewerId) {
		this.interviewId = interviewerId;
	}
	public String getInterviewDate() {
		return interviewDate;
	}
	public void setInterviewDate(String interviewDate) {
		this.interviewDate = interviewDate;
	}
	public String getInterviewVenue() {
		return interviewVenue;
	}
	public void setInterviewVenue(String interviewVenue) {
		this.interviewVenue = interviewVenue;
	}
	public int getOpportunityId() {
		return opportunityId;
	}
	@Override
	public String toString() {
		return "Job [JobId=" + JobId + ", jobTitle=" + jobTitle + ", eligibilityCriteria=" + eligibilityCriteria
				+ ", opportunityId=" + opportunityId + ", interviewId=" + interviewId + ", interviewDate="
				+ interviewDate + ", interviewVenue=" + interviewVenue + "]";
	}
	public int getJobId() {
		return JobId;
	}
	public void setJobId(int jobId) {
		JobId = jobId;
	}
	public String getJobTitle() {
		return jobTitle;
	}
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	public String getEligibilityCriteria() {
		return eligibilityCriteria;
	}
	public void setEligibilityCriteria(String eligibilityCriteria) {
		this.eligibilityCriteria = eligibilityCriteria;
	}
	public void setOpportunityId(int opportunityId) {
		this.opportunityId = opportunityId;
	}
	
}
