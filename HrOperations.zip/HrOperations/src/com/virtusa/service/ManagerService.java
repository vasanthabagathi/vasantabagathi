package com.virtusa.service;

import java.sql.SQLException;
import java.util.List;
import com.virtusa.model.ManagerModel;

public interface ManagerService {

	public List<ManagerModel> retrieveApplicationService();
	public boolean scheduleInterviewService(ManagerModel managerModel);
	public ManagerModel retrieveInterviewer(String interviewerId);
	boolean storeApplicationService(ManagerModel managerModel);
	public List<ManagerModel> retrieveResultUpdate() throws ClassNotFoundException, SQLException;

}
