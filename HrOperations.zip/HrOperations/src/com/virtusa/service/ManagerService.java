package com.virtusa.service;

import java.util.List;
import com.virtusa.model.ManagerModel;

public interface ManagerService {

	public List<ManagerModel> retrieveApplicationService();
	public boolean storeApplicationService(ManagerModel managerModel);
	public ManagerModel retrieveInterviewer(int deptId);
}
