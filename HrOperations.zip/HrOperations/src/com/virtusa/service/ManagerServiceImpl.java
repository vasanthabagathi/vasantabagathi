package com.virtusa.service;

import java.util.ArrayList;
import java.util.List;

import com.virtusa.dao.ManagerDAO;
import com.virtusa.entities.Manager;
import com.virtusa.factory.FactoryManagerDAO;
import com.virtusa.model.ManagerModel;


public class ManagerServiceImpl implements ManagerService {
    private ManagerDAO managerDAO=null;
	public ManagerServiceImpl()
	{
    this.managerDAO=FactoryManagerDAO.createManagerDAO();
	}

	@Override
	public List<ManagerModel> retrieveApplicationService() {
		 List<Manager> applicationList=managerDAO.viewApplications();
		
		List<ManagerModel> managerModelList=new ArrayList<ManagerModel>();
		
		for(Manager manager:applicationList){
			
			ManagerModel managerM1=new ManagerModel();
			managerM1.setInterviewDate(manager.getJob().getInterviewerId());
			managerM1.setInterviewDate(manager.getJob().getInterviewDate());
			managerM1.setInterviewVenue(manager.getJob().getInterviewVenue());
		}
		return managerModelList;
	}

	@Override
	public boolean storeApplicationService(ManagerModel managerModel) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ManagerModel retrieveInterviewer(int deptId) {
		// TODO Auto-generated method stub
		return null;
	}

}
