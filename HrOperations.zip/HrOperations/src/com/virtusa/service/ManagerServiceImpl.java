package com.virtusa.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.dao.ManagerDAO;
import com.virtusa.entities.Manager;
import com.virtusa.factory.FactoryManagerDAO;
import com.virtusa.model.ManagerModel;


public class ManagerServiceImpl implements ManagerService {
    private ManagerDAO managerDAO=null;
	public ManagerServiceImpl()
	{
    this.managerDAO=FactoryManagerDAO.createManagerDAO();
	}

	@Override
	public List<ManagerModel> retrieveApplicationService() {
		 List<Manager> applicationList=managerDAO.viewApplications();
		
		List<ManagerModel> managerModelList=new ArrayList<ManagerModel>();
		
		for(Manager manager:applicationList){
			
			ManagerModel managerM1=new ManagerModel();
			managerM1.setInterviewerId(manager.getJob().getInterviewerId());
			managerM1.setDate(manager.getJob().getInterviewDate());
			managerM1.setVenue(manager.getJob().getInterviewVenue());
		}
		return managerModelList;
	}

	@Override
	public boolean storeApplicationService(ManagerModel managerModel) {
		// TODO Auto-generated method stub
		return false;
	}

	

	@Override
	public boolean scheduleInterviewService(ManagerModel managerModel) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ManagerModel retrieveInterviewer(String interviewerId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public List<ManagerModel>retrieveResultUpdate() throws ClassNotFoundException, SQLException
	{
		List<Manager> resultUpdateStatusList=managerDAO.viewResultUpdate();
		List<ManagerModel> managerModelList=new ArrayList<ManagerModel>();
		for(Manager manager:resultUpdateStatusList)
		{
			ManagerModel managerMdl=new ManagerModel();
			managerMdl.setResultUpdate(manager.getResultUpdate());
			managerModelList.add(managerMdl);
		}
		return managerModelList;
	}

}
